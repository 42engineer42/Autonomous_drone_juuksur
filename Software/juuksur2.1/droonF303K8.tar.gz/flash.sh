st-flash write build/droonF303K8.bin 0x8000000
